<div id="sobre_mim"> 

<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="4"></button>
  </div>

  <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/unha1.jpeg" alt="Unha 1" class="d-block" width="700px" height="800px"> 
      <div class="carousel-caption">
    <h3>Meu trabalho</h3>
    <p>Manicure</p>
  </div>
    </div>

    <div class="carousel-item">
      <img src="img/unha2.jpeg" alt="Unha 2" class="d-block" width="700px" height="800px">
    </div>

    <div class="carousel-item">
      <img src="img/unha3.jpeg" alt="Unha 3" class="d-block"  width="700px" height="800px">
    </div>

    <div class="carousel-item">
      <img src="img/alunos.jpeg" alt="Unha 4" class="d-block"  width="700px" height="800px">

      <div class="carousel-caption">
    <h3 style="background-color:black">Alunos</h3>
    <p>Bolsa de Extensão Cursinho Popular</p>
  </div>
     
    </div>

  <div class="carousel-item">
      <img src="img/info.jpeg" alt="Unha 5" class="d-block"  width="700px" height="800px">

      <div class="carousel-caption">
    <h3>Instituto Federal</h3>
    <p>Ensino Médio integrado a informática</p>
  </div>

    </div>

  </div>

  

  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>


</div>
