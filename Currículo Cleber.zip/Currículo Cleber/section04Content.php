
<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("#hide").click(function(){
    $("p").hide();
  });
  $("#show").click(function(){
    $("p").show();
  });
});
</script>
</head>

<body>
<div id="mostrar" style="background-color:white; margin-left:150px; border-radius:  5px 5px 5px 5px; font-family:new time roman; padding: 10px 10px; width:400px; margin-top:240px">
<p><b>Meus contatos<b>

<br> <br><a href="https://www.facebook.com/catarina.soares.7140497" class="me-4 text-reset">
        <i class="fab fa-facebook-f" style="color:black;"></i>&nbsp&nbsp&nbsp Facebook - Catarina Soares
         </a> <br><br>

        <a href="https://www.instagram.com/catwrina_/" class="me-4 text-reset">
        <i class="fab fa-instagram"></i>&nbsp&nbsp&nbsp Instagram - Catarina Soares
        </a><br><br>

      
         <a href="https://github.com/Catinha/catarina-perfil" class="me-4 text-reset">
        <i class="fab fa-github" style="color:black;"></i>&nbsp&nbsp&nbspGitHub - Catarina Soares
        </a><br><br>

        <i class="fas fa-envelope me-3"style="color:black;"></i> catarina.a@aluno.edu.com.br
        
		<br> 

        
        <i class="fas fa-phone me-3"style="color:black;"></i> <br>(11) 96023-0336
      
         
        </a>


</p>
        </div>

    

<button id="hide" class="btn " style="margin-left:280px; margin-top:20px; background-color:#DB7093; color: white">Hide</button>
<button id="show" class="btn " style="margin-left:40px; margin-top:20px; background-color:#DB7093; color: white">Show</button>
</div>

</body>
</html>
