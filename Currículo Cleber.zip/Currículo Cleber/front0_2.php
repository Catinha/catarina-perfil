
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>insert title here</title>
<style type="text/css">

header{
				width: 100%;
				height: 30px;
				float: left;
				padding: 20px 10px;
				display: inline-bolck;
				text-align: center;
				font-family: "Trebuchet MS", Helvetica, sans-serif;
				font-size: 16px;
				
			}
			
			.sct{
				width: 50%;
				height: 800px;
				float: left;
				margin-top: 50px;;
			}
		
			#sobre_mim 
			{
            padding: 10px 10px;
			}
			


#banner {

margin-top: -10px;

}


			#sct01{
				background-color: #FAF0E6;
			margin-top:60px;
				
			}
			#sct02{
				background-color:#white;
			}

			}
			
			 #usu�rio {
			 
			   	margin-top: 70px;
				margin-left: 160px;
				margin-bottom: 200px;
				}
			 
			 
			 #usu�rio_2 {width: 230px;
    			height: 220px;
				margin-top: 60px;
				margin-left: 13px;
				
				}
			
			.texto1 {

				background-color: grey;
				width:500px;
				margin-bottom:100px;
				margin-left: 80px;


			}

			footer{
				width: 138%;
				height: 30px;
				float: left;
				text-align: center;		
				padding: 20px 10px;	
				margin-top: 10px;
			}

		</style>

<script src="https://kit.fontawesome.com/21e81e15bc.js" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
	
				$(document).ready(function() {
					$("#header").load("headerContent.php"   );
					$("#sct01" ).load("section01Content.php");
					$("#sct02" ).load("section02Content.php");
					$("#footer").load("footerContent.php"   );
				});

				
		</script>

	</head>
<body>
	<header id="header">innerHTML header</header>
	<section class="sct" id="sct01" >innerHTML sct01</section>
	<section class="sct" id="sct02">innerHTML sct02</section>
	<footer id="footer">innerHTML footer</footer>
</body>
</html>