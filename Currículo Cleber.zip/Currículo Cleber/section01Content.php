
<div id = "usu�rio">

<div class="toast show" style="margin-left: 170px; margin-top:50px;">
  <div class="toast-header">
    Apresentação
    <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
  </div>
  <div class="toast-body" style="margin">
  Oiii, tudo bem?
<br>Meu nome é Catarina Soares de Araújo, tenho 18 anos e moro em Guarulhos, São Paulo.<br>
Atualmente, estou estudando no Instituto Federal de Ciências e Tecnologia, cursando o último ano do meu Ensino Médio integrado com o Técnico em Informática para Internet. 
Nas horas vagas, trabalho como manicure e nail designer.
<p>Caso tenha se interessado, clique em ver mais.</p>

  </div>
</div>

<div class="card" style="width:200px; height: 400px;   margin-left: 240px; margin-top:50px; ">
  <img class="card-img-top" src="img/catarinalinda.jpeg" style="200px" alt="Card image" >
  <div class="card-body">
    <h4 class="card-title">Catarina Soares</h4>
    <p class="card-text">São Paulo, Guarulhos, 18 anos.</p>
    <a href="#" class="btn" id="btnSct01" value="Login" style="background-color:#DB7093; color: white">Ver mais...</a>
  </div>
</div>


<script type="text/javascript">
	$(document).ready(function() {
		$("#btnSct01").click(function() {
			$("#sct01" ).load("section03Content.php");
		});
	});
</script>
</div>
