



<div id = "usu�rio_2">


<div class = "texto1" style="border-radius:  5px 5px 5px 5px; font-family:new time roman; padding: 20px 10px; background-color:white " >
<b>Educação</b> <br>
<br>- Ensino fundamental I : EPG Crispiniano Soares (concluído)<br>
- Ensino fundamental II : EE Benedita de Oliveira Ale (concluído)<br>
- Ensino Médio : Instituto Federal de Ciências e Tecnologia (cursando)<br>
- Curso de Música (2012-2019) : Conservatório Municipal de Guarulhos (concluído)<br>
- Curso Manicure : Laís Forte Nails (concluído)<br>
- Curso Nail Designer : Janaína Alves Nails (concluído)<br>
- Curso Nail Designer 5 estrelas : Carol Veltenn (concluído)<br>
- Curso de Libras : Instituto Federal (cursando)<br>

<br><b>Habilidades</b><br>
<br>- Sei tocar 3 instrumentos: Violão, Teclado e Ukulelê. <br>
- Atuei por 3 anos na companhia Família BOA.<br>
- Conheço a estrutura das linguagens de programação html, css e php.<br>
- Participei da bolsa de extensão “Cursinho Popular : Sônia Guimarães” no Instituo Federal como professora de Geografia por 1 ano. <br>

<br><b>Interesses</b><br>
<br>- Atualmente, tenho me interessado mais pelo meu curso técnico e pensado em como ele poderá contribuir em minha carreira profissional. Ainda não sei qual faculdade pretendo cursar, mas provavelmente será na área de humanas. Sou muito dedicada e perfeccionista com tudo o que me proponho a fazer, tenho como missão acrescentar, mudar e propor soluções por onde eu for.

<br><a href="#" class="btn" id="btnSct01" value="Login" style="margin-left:180px; background-color:#DB7093; color: white ">Ver mais...</a>

  </div>
</div>



<script type="text/javascript">
	$(document).ready(function() {
		$("#btnSct01").click(function() {
			$("#sct01" ).load("section04Content.php");
		});
	});
</script>

