<div id = "banner">
<nav class="navbar navbar-expand-sm navbar-dark">
  <div class="container-fluid" style="background-color:#DB7093; padding: 10px 10px">
    <a class="navbar-brand" href="#" style="font-family: new time roman; font-size: 20px; margin-left: 500px ;" > &copy todos os direitos são reservados
  </div>
</nav>
</div>